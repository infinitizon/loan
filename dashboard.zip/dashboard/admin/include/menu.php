<!--------------------
START - Top Bar
-------------------->
<div class="top-bar color-scheme-dark"><div class="logo-w menu-size">
<a class="logo" href="#"><div class="logo-element">
</div>
<div class="logo-label">Bank Admin</div></a>
</div>

<a class="btn btn-danger" href="<?php echo WEB_ROOT; ?>admin/"><i class="fas fa-home"></i><span>Home</span></a>
<!--------------------
START - Top Menu Controls
-------------------->

<!--------------------

<!--------------------
START - Settings Link in secondary top menu
-------------------->


<!--------------------
END - Settings Link in secondary top menu
--------------------><!--------------------
START - User avatar and menu in secondary top menu
-------------------->
<div class="logged-user-w"><div class="logged-user-i">
<div class="avatar-w"><img alt="" src="img/avatar1.jpg"></div>
<div class="logged-user-menu color-style-bright">
<div class="logged-user-avatar-info">
<div class="avatar-w"><img alt="" src="img/avatar1.jpg">
</div><div class="logged-user-info-w">
<div class="logged-user-name">Admin</div>
<div class="logged-user-role">Member</div></div></div>
<div class="bg-icon"><i class="os-icon os-icon-wallet-loaded"></i></div>
<ul>
<li>
<a href="<?php echo $self; ?>?logout"><i class="os-icon os-icon-signs-11"></i><span>Logout</span></a></li></ul></div></div></div>
<!--------------------
END - User avatar and menu in secondary top menu
--------------------></div><!--------------------
END - Top Menu Controls
--------------------></div><!--------------------
END - Top Bar
-------------------->


</div></div></div>
<div class="layout-w">
<!--------------------
START - Mobile Menu
-------------------->
<div class="menu-mobile menu-activated-on-click color-scheme-dark">
<div class="mm-logo-buttons-w"><a class="mm-logo" href="#">
<img src="img/logo.png"><span>Bank Admin</span></a>
<div class="mm-buttons"><div class="content-panel-open">
<div class="os-icon os-icon-grid-circles"></div></div>
<div class="mobile-menu-trigger">
<div class="os-icon os-icon-hamburger-menu-1"></div>
</div></div></div>
<div class="menu-and-user">
<div class="logged-user-w">
<div class="avatar-w"><img alt="" src="img/avatar1.jpg"></div>
<div class="logged-user-info-w"><div class="logged-user-name">Admin</div>
<div class="logged-user-role">Member</div></div></div>
<!--------------------
START - Mobile Menu List
-------------------->
<ul class="main-menu">
<li class="sub-header">
<span>BANK ADMIN</span></li>

<li><a href="<?php echo WEB_ROOT; ?>admin/">
<div class="icon-w"><div class="fas fa-home"></div></div>
<span>Home</span></a></li>

<li><a href="<?php echo WEB_ROOT; ?>admin/user/">
<div class="icon-w"><div class="fas fa-user"></div></div>
<span>User Details</span></a></li>


<li><a href="<?php echo WEB_ROOT; ?>admin/account/">
<div class="icon-w"><div class="fas fa-user"></div></div>
<span>Fund Account</span></a></li>
 

 <li><a href="<?php echo WEB_ROOT; ?>admin/pwd/">
<div class="icon-w"><div class="fas fa-user"></div></div>
<span>Change User Details</span></a></li>

<li><a href="<?php echo WEB_ROOT; ?>admin/ticket.php">
<div class="icon-w"><div class="fas fa-envelope"></div></div>
<span>Messages</span></a></li>

<li><a href="<?php echo $self; ?>?logout">
<div class="icon-w"><div class="fas fa-sign-out-alt"></div></div>
<span>logout</span></a></li>


</ul>

<!--------------------
END - Mobile Menu List
-------------------->
<div class="mobile-menu-magic">
<h4>By Mr Paul Web Design</h4>
<p>Email: paulbolashagy@gmail.com</p>
<p>WhatsApp: +2349064573712</p>
</div></div></div>

<!--------------------
END - Mobile Menu
--------------------><!--------------------
START - Main Menu
-------------------->

<div class="menu-w color-scheme-dark color-style-bright menu-position-side menu-side-left menu-layout-compact sub-menu-style-over 
sub-menu-color-bright selected-menu-color-blue menu-activated-on-hover menu-has-selected-link">

<div class="menu-actions"><!--------------------
START - Messages Link in secondary top menu
-------------------->

<!--------------------
END - Messages Link in secondary top menu
--------------------><!--------------------
START - Settings Link in secondary top menu
-------------------->

<!--------------------
END - Settings Link in secondary top menu
--------------------><!--------------------
START - Messages Link in secondary top menu
-------------------->

<!--------------------
END - Messages Link in secondary top menu
-------------------->
</div>

<h1 class="menu-page-header">Page Header</h1>
<ul class="main-menu">
<li class="sub-header">
<span>BANK ADMIN</span></li>


<li><a href="<?php echo WEB_ROOT; ?>admin/">
<div class="icon-w"><div class=" fas fa-home"></div></div>
<span>Home</span></a></li>

<li><a href="<?php echo WEB_ROOT; ?>admin/user/">
<div class="icon-w"><div class="fas fa-user"></div></div>
<span>User Details</span></a></li>


<li><a href="<?php echo WEB_ROOT; ?>admin/account/">
<div class="icon-w"><div class="fas fa-user"></div></div>
<span>Fund Account</span></a></li>
 
 
 <li><a href="<?php echo WEB_ROOT; ?>admin/pwd/">
<div class="icon-w"><div class="fas fa-user"></div></div>
<span>Change User Details</span></a></li>

<li><a href="<?php echo WEB_ROOT; ?>admin/ticket.php">
<div class="icon-w"><div class="fas fa-envelope"></div></div>
<span>Messages</span></a></li>

<li><a href="<?php echo $self; ?>?logout">
<div class="icon-w"><div class="fas fa-sign-out-alt"></div></div>
<span>logout</span></a></li>

</ul>
<div class="side-menu-magic">
<h4>By Mr Paul Web Design</h4>
<p>Email: paulbolashagy@gmail.com</p>
<p>WhatsApp: +2349064573712</p>

 
 </div></div>
 <!--------------------
END - Main Menu
-------------------->