
<div class="content-w"><div class="content-i">
<div class="content-box">
<div class="element-wrapper compact pt-4">



<h6 class="element-header">Welcome Admin</h6>
<div class="element-box-tp"><div class="row">
<div class="col-lg-7 col-xxl-6">
<!--START - BALANCES-->
<div class="element-balances">
<div class="balance hidden-mobile">
<div class="balance-title">Account Details</div>

<div class="balance-link"><a class="btn btn-link btn-underlined" href="<?php echo WEB_ROOT; ?>admin/account/">
<span>View Accounts On This Bank</span><i class="os-icon os-icon-arrow-right4"></i></a></div>
</div>
<div class="balance"><div class="balance-title">Account Profiles</div>

<div class="balance-link"><a class="btn btn-link btn-underlined btn-gold" href="<?php echo WEB_ROOT; ?>admin/user/"><span>View Profiles On This Bank</span>
<i class="os-icon os-icon-arrow-right4"></i></a></div></div></div>

<!--END - BALANCES-->
</div><div class="col-lg-5 col-xxl-6">

<!--START - MESSAGE ALERT-->

<div class="alert alert-warning borderless">
<h5 class="alert-heading">How To Activate Account</h5>
<p>Dear &nbsp;Admin, To activate account, click on <a href="<?php echo WEB_ROOT; ?>admin/user/"> User Details</a> click on Incative to activate the account and also do thesame on 
<a href="<?php echo WEB_ROOT; ?>admin/account/"> Account Details </a> to activate the account. without activating the account you cannot login.   </p>

</div><!--END - MESSAGE ALERT--></div></div></div>
</div>
<div class="row">
<div class="col-lg-7 col-xxl-6">


<!--START - MESSAGE ALERT-->

<div class="alert alert-warning borderless">
<h5 class="alert-heading">How To Fund</h5>
<p>To Fund the Account, click on Account Details, click on the account number, and select a transaction option to credit.</p>
</div><!--END - MESSAGE ALERT-->


</div>




</div>
</div>
