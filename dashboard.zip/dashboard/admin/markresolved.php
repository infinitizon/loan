<?php

require_once '../library/config.php';
include '../tickets/manage/markresolved.php';



?>