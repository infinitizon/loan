
<div class="content-w"><div class="content-i">
<div class="content-box">
<div class="element-wrapper compact pt-4">



<h6 class="element-header">Welcome Admin</h6>
<div class="element-box-tp"><div class="row">
<div class="col-lg-7 col-xxl-6">
<!--START - BALANCES-->
<div class="element-balances">
<div class="balance hidden-mobile">
<div class="balance-title">Ban Updated</div>

<div class="balance-link"><a class="btn btn-link btn-underlined" href="<?php echo WEB_ROOT; ?>admin/account/">
<span>View Accounts On This Bank</span><i class="os-icon os-icon-arrow-right4"></i></a></div>
</div>
<div class="balance">
    
</div></div>

<!--END - BALANCES-->
</div><div class="col-lg-5 col-xxl-6">

<!--START - MESSAGE ALERT-->

<div class="alert alert-warning borderless">
<h5 class="alert-heading">Ban Updated Successfully</h5>
<p>Ban has been updated successfully bro. Thank you


</div><!--END - MESSAGE ALERT--></div></div></div>
</div>
<div class="row">
<div class="col-lg-7 col-xxl-6">


<!--START - MESSAGE ALERT-->


</div>




</div>
</div>