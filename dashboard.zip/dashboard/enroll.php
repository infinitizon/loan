<script type="text/javascript">location.href = 'login.php';</script>
