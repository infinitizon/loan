
<nav class="layout-footer footer footer-light">
<div class="container-fluid d-flex flex-wrap justify-content-between text-center container-p-x pb-3">
<div class="pt-3">
<span class="float-md-right d-none d-lg-block">&copy; 2020 - <?php echo $site_title; ?> -All Rights Reserved. </span>
</div>
<div>

</div>
</div>
</nav>

</div>

</div>

</div>

<div class="layout-overlay layout-sidenav-toggle"></div>
</div>


<script src="<?php echo WEB_ROOT; ?>assets/js/pace.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/popper/popper.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/bootstrap.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/sidenav.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/layout-helpers.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/material-ripple.js"></script>

<script src="<?php echo WEB_ROOT; ?>assets/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/eve/eve.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/flot/flot.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/flot/curvedLines.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/chart-am4/core.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/chart-am4/charts.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/chart-am4/animated.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/raphael/raphael.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/morris/morris.js"></script>

<script src="assets/js/analytics.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/pages/dashboards_ecommerce.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/spin/spin.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/ladda/ladda.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/pages/misc_ladda.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/js/pages/pages_messages.js"></script>

<script src="<?php echo WEB_ROOT; ?>assets/libs/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="<?php echo WEB_ROOT; ?>assets/libs/select2/select2.js"></script>

</body>
</html>
